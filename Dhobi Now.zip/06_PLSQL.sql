-- ============================================================
--  DhobiNow Smart Laundry Management System
--  Script: 04_PLSQL.sql
--  Oracle APEX / Oracle 21c XE
--  Run AFTER: 01_DDL.sql, 02_DML_INSERT.sql
-- ============================================================


-- ============================================================
-- SECTION A: FUNCTIONS (2+ required, 1 called in SELECT)
-- ============================================================

-- Function 1: Calculate total bill for an order
CREATE OR REPLACE FUNCTION get_order_total(p_order_id IN NUMBER)
RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT NVL(SUM(price), 0)
    INTO v_total
    FROM order_items
    WHERE order_id = p_order_id;
    RETURN v_total;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN 0;
    WHEN OTHERS THEN RETURN -1;
END get_order_total;
/

-- Test Function 1 inside a SELECT statement (required)
SELECT
    o.order_id,
    u.name            AS customer_name,
    o.status,
    o.total_amount    AS stored_total,
    get_order_total(o.order_id) AS calculated_total
FROM orders o
JOIN users u ON o.user_id = u.user_id;

-- Function 2: Get full status label with emoji for display
CREATE OR REPLACE FUNCTION get_status_label(p_status IN VARCHAR2)
RETURN VARCHAR2 IS
BEGIN
    RETURN CASE p_status
        WHEN 'Pending'          THEN '⏳ Pending'
        WHEN 'Confirmed'        THEN '✅ Confirmed'
        WHEN 'Picked Up'        THEN '🚗 Picked Up'
        WHEN 'Washing'          THEN '🫧 Washing'
        WHEN 'Drying'           THEN '💨 Drying'
        WHEN 'Ironing'          THEN '👔 Ironing'
        WHEN 'Ready'            THEN '📦 Ready'
        WHEN 'Out for Delivery' THEN '🚴 Out for Delivery'
        WHEN 'Delivered'        THEN '🎉 Delivered'
        WHEN 'Cancelled'        THEN '❌ Cancelled'
        ELSE '❓ Unknown'
    END;
END get_status_label;
/

-- Test Function 2 inside SELECT
SELECT
    order_id,
    get_status_label(status) AS status_display,
    total_amount
FROM orders
ORDER BY order_date DESC;

-- Function 3: Count total orders for a customer
CREATE OR REPLACE FUNCTION get_customer_order_count(p_user_id IN NUMBER)
RETURN NUMBER IS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM orders
    WHERE user_id = p_user_id;
    RETURN v_count;
EXCEPTION
    WHEN OTHERS THEN RETURN 0;
END get_customer_order_count;
/

-- Test Function 3 in SELECT
SELECT
    user_id, name, phone,
    get_customer_order_count(user_id) AS total_orders
FROM users
WHERE role = 'customer';


-- ============================================================
-- SECTION B: TRIGGERS (BEFORE insert, AFTER UPDATE, AFTER DELETE)
-- ============================================================

-- Trigger 1: BEFORE INSERT — Validate order data before inserting
CREATE OR REPLACE TRIGGER trg_before_order_insert
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
    -- Set default status if not provided
    IF :NEW.status IS NULL THEN
        :NEW.status := 'Pending';
    END IF;

    -- Set default total amount
    IF :NEW.total_amount IS NULL THEN
        :NEW.total_amount := 0;
    END IF;

    -- Set default payment method
    IF :NEW.payment_method IS NULL THEN
        :NEW.payment_method := 'COD';
    END IF;

    -- Set order_date to now if not provided
    IF :NEW.order_date IS NULL THEN
        :NEW.order_date := SYSTIMESTAMP;
    END IF;

    -- Validate pickup_date is in the future
    IF :NEW.pickup_date IS NOT NULL AND :NEW.pickup_date < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20010, 'Pickup date cannot be in the past');
    END IF;
END trg_before_order_insert;
/

-- Trigger 2: AFTER UPDATE — Audit log when order status changes
CREATE OR REPLACE TRIGGER trg_after_order_status_update
AFTER UPDATE OF status ON orders
FOR EACH ROW
WHEN (OLD.status != NEW.status)
BEGIN
    INSERT INTO delivery_status (
        status_id, order_id, status_label, updated_at, updated_by
    ) VALUES (
        delivery_seq.NEXTVAL,
        :NEW.order_id,
        :NEW.status,
        SYSTIMESTAMP,
        'System Trigger'
    );
END trg_after_order_status_update;
/

-- Trigger 3: AFTER DELETE — Archive deleted orders
-- First create archive table if not exists
BEGIN
    EXECUTE IMMEDIATE '
        CREATE TABLE deleted_orders_archive (
            archive_id    NUMBER PRIMARY KEY,
            order_id      NUMBER,
            user_id       NUMBER,
            order_date    TIMESTAMP,
            status        VARCHAR2(50),
            total_amount  NUMBER,
            deleted_at    TIMESTAMP DEFAULT SYSTIMESTAMP,
            deleted_by    VARCHAR2(100) DEFAULT ''System''
        )';
EXCEPTION
    WHEN OTHERS THEN NULL; -- Table already exists
END;
/

CREATE SEQUENCE archive_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER trg_after_order_delete
AFTER DELETE ON orders
FOR EACH ROW
BEGIN
    INSERT INTO deleted_orders_archive (
        archive_id, order_id, user_id, order_date,
        status, total_amount, deleted_at
    ) VALUES (
        archive_seq.NEXTVAL,
        :OLD.order_id,
        :OLD.user_id,
        :OLD.order_date,
        :OLD.status,
        :OLD.total_amount,
        SYSTIMESTAMP
    );
END trg_after_order_delete;
/

-- Trigger 4: AFTER INSERT/UPDATE/DELETE on ORDER_ITEMS — update total
CREATE OR REPLACE TRIGGER trg_update_order_total
AFTER INSERT OR UPDATE OR DELETE ON order_items
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        UPDATE orders SET total_amount = total_amount + :NEW.price
        WHERE order_id = :NEW.order_id;
    ELSIF DELETING THEN
        UPDATE orders SET total_amount = total_amount - :OLD.price
        WHERE order_id = :OLD.order_id;
    ELSIF UPDATING THEN
        UPDATE orders SET total_amount = total_amount - :OLD.price + :NEW.price
        WHERE order_id = :NEW.order_id;
    END IF;
END trg_update_order_total;
/


-- ============================================================
-- SECTION C: STORED PROCEDURES (3+ required)
-- ============================================================

-- Procedure 1: Place a new order (with IN/OUT params + exception handling)
CREATE OR REPLACE PROCEDURE place_order (
    p_user_id        IN  NUMBER,
    p_pickup_date    IN  DATE,
    p_time_slot      IN  VARCHAR2,
    p_address        IN  VARCHAR2,
    p_notes          IN  VARCHAR2 DEFAULT NULL,
    p_pickup_type    IN  VARCHAR2 DEFAULT 'pickup',
    p_return_type    IN  VARCHAR2 DEFAULT 'deliver',
    p_payment_method IN  VARCHAR2 DEFAULT 'COD',
    p_order_id       OUT NUMBER
)
IS
    v_schedule_id NUMBER;
    v_user_count  NUMBER;
BEGIN
    -- Validate user exists
    SELECT COUNT(*) INTO v_user_count FROM users WHERE user_id = p_user_id AND is_active = 1;
    IF v_user_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'User not found or inactive');
    END IF;

    -- Get next IDs
    SELECT orders_seq.NEXTVAL   INTO p_order_id    FROM DUAL;
    SELECT schedule_seq.NEXTVAL INTO v_schedule_id FROM DUAL;

    -- Insert order
    INSERT INTO orders (
        order_id, user_id, order_date, pickup_date, status, total_amount,
        notes, pickup_type, return_type, payment_method, payment_status
    ) VALUES (
        p_order_id, p_user_id, SYSDATE, p_pickup_date, 'Pending', 0,
        NVL(p_notes, ''), p_pickup_type, p_return_type, p_payment_method, 'Pending'
    );

    -- Insert pickup schedule
    INSERT INTO pickup_schedule (
        schedule_id, order_id, scheduled_date, time_slot, address, pickup_status
    ) VALUES (
        v_schedule_id, p_order_id, p_pickup_date, p_time_slot, p_address, 'Confirmed'
    );

    -- Log initial status
    INSERT INTO delivery_status (status_id, order_id, status_label, updated_at, updated_by)
    VALUES (delivery_seq.NEXTVAL, p_order_id, 'Order Placed', SYSTIMESTAMP, 'Customer');

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Order #' || p_order_id || ' placed successfully.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error placing order: ' || SQLERRM);
        RAISE;
END place_order;
/

-- Procedure 2: Assign dhobi to an order (with validation)
CREATE OR REPLACE PROCEDURE assign_dhobi(
    p_order_id IN NUMBER,
    p_dhobi_id IN NUMBER
)
IS
    v_role       VARCHAR2(20);
    v_order_count NUMBER;
BEGIN
    -- Validate dhobi exists and is a dhobi
    SELECT role INTO v_role FROM users WHERE user_id = p_dhobi_id AND is_active = 1;
    IF v_role != 'dhobi' THEN
        RAISE_APPLICATION_ERROR(-20002, 'User is not a registered dhobi');
    END IF;

    -- Validate order exists
    SELECT COUNT(*) INTO v_order_count FROM orders WHERE order_id = p_order_id;
    IF v_order_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20003, 'Order not found');
    END IF;

    -- Remove old assignment if any
    DELETE FROM assignments WHERE order_id = p_order_id;

    -- Create new assignment
    INSERT INTO assignments (assign_id, order_id, dhobi_id, assigned_at)
    VALUES (assign_seq.NEXTVAL, p_order_id, p_dhobi_id, SYSDATE);

    -- Update order status to Confirmed
    UPDATE orders SET status = 'Confirmed' WHERE order_id = p_order_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Dhobi ' || p_dhobi_id || ' assigned to order ' || p_order_id);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20004, 'Dhobi or Order not found');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        RAISE;
END assign_dhobi;
/

-- Procedure 3: Update order status through the pipeline
CREATE OR REPLACE PROCEDURE update_order_status(
    p_order_id   IN NUMBER,
    p_new_status IN VARCHAR2,
    p_updated_by IN VARCHAR2 DEFAULT 'System'
)
IS
    v_current_status VARCHAR2(50);
    v_valid_statuses SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST(
        'Pending','Confirmed','Picked Up','Washing',
        'Drying','Ironing','Ready','Out for Delivery','Delivered','Cancelled'
    );
    v_is_valid NUMBER := 0;
BEGIN
    -- Get current status
    SELECT status INTO v_current_status FROM orders WHERE order_id = p_order_id;

    -- Validate new status
    FOR i IN 1..v_valid_statuses.COUNT LOOP
        IF v_valid_statuses(i) = p_new_status THEN
            v_is_valid := 1;
        END IF;
    END LOOP;

    IF v_is_valid = 0 THEN
        RAISE_APPLICATION_ERROR(-20005, 'Invalid status: ' || p_new_status);
    END IF;

    -- Update status
    UPDATE orders SET status = p_new_status WHERE order_id = p_order_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Order #' || p_order_id || ' status: ' || v_current_status || ' → ' || p_new_status);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20006, 'Order ' || p_order_id || ' not found');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END update_order_status;
/


-- ============================================================
-- SECTION D: EXPLICIT CURSORS (2+ required, 1 parameterized)
-- ============================================================

-- Cursor 1: Parameterized cursor — all orders for a specific dhobi
DECLARE
    -- Parameterized cursor
    CURSOR c_dhobi_orders(p_dhobi_id NUMBER) IS
        SELECT o.order_id, u.name AS customer, o.status, o.total_amount
        FROM orders o
        JOIN assignments a ON o.order_id = a.order_id
        JOIN users u       ON o.user_id  = u.user_id
        WHERE a.dhobi_id = p_dhobi_id
        ORDER BY o.order_date DESC;

    v_order   c_dhobi_orders%ROWTYPE;
    v_total   NUMBER := 0;
    v_count   NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== Orders for Dhobi ID: 3 ===');
    OPEN c_dhobi_orders(3);  -- Pass dhobi_id as parameter
    LOOP
        FETCH c_dhobi_orders INTO v_order;
        EXIT WHEN c_dhobi_orders%NOTFOUND;

        v_count := v_count + 1;
        v_total := v_total + v_order.total_amount;
        DBMS_OUTPUT.PUT_LINE(
            'Order #' || v_order.order_id ||
            ' | Customer: ' || v_order.customer ||
            ' | Status: ' || v_order.status ||
            ' | Amount: Rs ' || v_order.total_amount
        );
    END LOOP;
    CLOSE c_dhobi_orders;

    DBMS_OUTPUT.PUT_LINE('Total Orders: ' || v_count);
    DBMS_OUTPUT.PUT_LINE('Total Revenue: Rs ' || v_total);
END;
/

-- Cursor 2: Report all pending orders using OPEN/FETCH/CLOSE
DECLARE
    CURSOR c_pending_orders IS
        SELECT o.order_id, u.name, u.phone, o.order_date, o.total_amount
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.status = 'Pending'
        ORDER BY o.order_date ASC;

    v_rec     c_pending_orders%ROWTYPE;
    v_count   NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== PENDING ORDERS REPORT ===');
    DBMS_OUTPUT.PUT_LINE(RPAD('Order ID', 10) || RPAD('Customer', 20) || RPAD('Phone', 15) || 'Amount');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 60, '-'));

    OPEN c_pending_orders;
    LOOP
        FETCH c_pending_orders INTO v_rec;
        EXIT WHEN c_pending_orders%NOTFOUND;

        v_count := v_count + 1;
        DBMS_OUTPUT.PUT_LINE(
            RPAD(v_rec.order_id, 10) ||
            RPAD(v_rec.name, 20) ||
            RPAD(v_rec.phone, 15) ||
            'Rs ' || v_rec.total_amount
        );
    END LOOP;
    CLOSE c_pending_orders;

    DBMS_OUTPUT.PUT_LINE(RPAD('-', 60, '-'));
    DBMS_OUTPUT.PUT_LINE('Total Pending Orders: ' || v_count);
END;
/


-- ============================================================
-- SECTION E: PACKAGE (1 required: 2+ procs, 1+ func, 1 constant)
-- ============================================================

-- Package Specification
CREATE OR REPLACE PACKAGE dhobinow_pkg AS

    -- Package-level constants
    c_app_name     CONSTANT VARCHAR2(50) := 'DhobiNow Laundry System';
    c_version      CONSTANT VARCHAR2(10) := '1.0.0';
    c_max_items    CONSTANT NUMBER       := 50;

    -- Package-level variable (tracks operations)
    g_operations_count NUMBER := 0;

    -- Function declarations
    FUNCTION calculate_bill(p_order_id IN NUMBER) RETURN NUMBER;
    FUNCTION get_dhobi_rating(p_dhobi_id IN NUMBER) RETURN VARCHAR2;

    -- Procedure declarations
    PROCEDURE generate_daily_report(p_date IN DATE DEFAULT SYSDATE);
    PROCEDURE reassign_pending_orders(p_from_dhobi IN NUMBER, p_to_dhobi IN NUMBER);
    PROCEDURE print_order_summary(p_order_id IN NUMBER);

END dhobinow_pkg;
/

-- Package Body
CREATE OR REPLACE PACKAGE BODY dhobinow_pkg AS

    -- Function 1: Calculate bill for an order
    FUNCTION calculate_bill(p_order_id IN NUMBER) RETURN NUMBER IS
        v_total NUMBER;
    BEGIN
        SELECT NVL(SUM(price), 0) INTO v_total
        FROM order_items WHERE order_id = p_order_id;

        UPDATE orders SET total_amount = v_total WHERE order_id = p_order_id;
        COMMIT;

        g_operations_count := g_operations_count + 1;
        RETURN v_total;
    EXCEPTION
        WHEN OTHERS THEN RETURN 0;
    END calculate_bill;

    -- Function 2: Get dhobi performance rating
    FUNCTION get_dhobi_rating(p_dhobi_id IN NUMBER) RETURN VARCHAR2 IS
        v_total     NUMBER;
        v_completed NUMBER;
        v_rate      NUMBER;
    BEGIN
        SELECT COUNT(*), COUNT(CASE WHEN o.status = 'Delivered' THEN 1 END)
        INTO v_total, v_completed
        FROM assignments a JOIN orders o ON a.order_id = o.order_id
        WHERE a.dhobi_id = p_dhobi_id;

        IF v_total = 0 THEN RETURN 'No Orders'; END IF;

        v_rate := (v_completed / v_total) * 100;

        RETURN CASE
            WHEN v_rate >= 90 THEN '⭐⭐⭐⭐⭐ Excellent'
            WHEN v_rate >= 75 THEN '⭐⭐⭐⭐ Good'
            WHEN v_rate >= 60 THEN '⭐⭐⭐ Average'
            WHEN v_rate >= 40 THEN '⭐⭐ Below Average'
            ELSE '⭐ Poor'
        END;
    EXCEPTION
        WHEN OTHERS THEN RETURN 'Unknown';
    END get_dhobi_rating;

    -- Procedure 1: Generate daily report
    PROCEDURE generate_daily_report(p_date IN DATE DEFAULT SYSDATE) IS
        v_total_orders  NUMBER;
        v_total_revenue NUMBER;
        v_delivered     NUMBER;
        v_pending       NUMBER;
    BEGIN
        SELECT COUNT(*), NVL(SUM(total_amount), 0),
               COUNT(CASE WHEN status = 'Delivered' THEN 1 END),
               COUNT(CASE WHEN status = 'Pending'   THEN 1 END)
        INTO v_total_orders, v_total_revenue, v_delivered, v_pending
        FROM orders
        WHERE TRUNC(order_date) = TRUNC(p_date);

        DBMS_OUTPUT.PUT_LINE('========================================');
        DBMS_OUTPUT.PUT_LINE(c_app_name || ' v' || c_version);
        DBMS_OUTPUT.PUT_LINE('Daily Report: ' || TO_CHAR(p_date, 'DD-Mon-YYYY'));
        DBMS_OUTPUT.PUT_LINE('========================================');
        DBMS_OUTPUT.PUT_LINE('Total Orders  : ' || v_total_orders);
        DBMS_OUTPUT.PUT_LINE('Total Revenue : Rs ' || v_total_revenue);
        DBMS_OUTPUT.PUT_LINE('Delivered     : ' || v_delivered);
        DBMS_OUTPUT.PUT_LINE('Pending       : ' || v_pending);
        DBMS_OUTPUT.PUT_LINE('Operations    : ' || g_operations_count);
        DBMS_OUTPUT.PUT_LINE('========================================');

        g_operations_count := g_operations_count + 1;
    END generate_daily_report;

    -- Procedure 2: Reassign all orders from one dhobi to another
    PROCEDURE reassign_pending_orders(p_from_dhobi IN NUMBER, p_to_dhobi IN NUMBER) IS
        v_count NUMBER := 0;
    BEGIN
        FOR rec IN (
            SELECT a.order_id FROM assignments a
            JOIN orders o ON a.order_id = o.order_id
            WHERE a.dhobi_id = p_from_dhobi
              AND o.status NOT IN ('Delivered', 'Cancelled')
        ) LOOP
            UPDATE assignments
            SET dhobi_id = p_to_dhobi, assigned_at = SYSDATE
            WHERE order_id = rec.order_id;
            v_count := v_count + 1;
        END LOOP;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE(v_count || ' orders reassigned from dhobi ' || p_from_dhobi || ' to dhobi ' || p_to_dhobi);
        g_operations_count := g_operations_count + 1;
    END reassign_pending_orders;

    -- Procedure 3: Print full order summary
    PROCEDURE print_order_summary(p_order_id IN NUMBER) IS
        v_customer VARCHAR2(100);
        v_status   VARCHAR2(50);
        v_total    NUMBER;
        v_dhobi    VARCHAR2(100);
    BEGIN
        SELECT u.name, o.status, o.total_amount
        INTO v_customer, v_status, v_total
        FROM orders o JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = p_order_id;

        BEGIN
            SELECT u.name INTO v_dhobi
            FROM assignments a JOIN users u ON a.dhobi_id = u.user_id
            WHERE a.order_id = p_order_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN v_dhobi := 'Unassigned';
        END;

        DBMS_OUTPUT.PUT_LINE('--- Order #' || p_order_id || ' Summary ---');
        DBMS_OUTPUT.PUT_LINE('Customer : ' || v_customer);
        DBMS_OUTPUT.PUT_LINE('Status   : ' || get_status_label(v_status));
        DBMS_OUTPUT.PUT_LINE('Dhobi    : ' || v_dhobi);
        DBMS_OUTPUT.PUT_LINE('Total    : Rs ' || v_total);
        DBMS_OUTPUT.PUT_LINE('Rating   : ' || get_dhobi_rating(
            NVL((SELECT dhobi_id FROM assignments WHERE order_id = p_order_id), 0)
        ));

        g_operations_count := g_operations_count + 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Order #' || p_order_id || ' not found.');
    END print_order_summary;

END dhobinow_pkg;
/

-- Test the package
BEGIN
    -- Test daily report
    dhobinow_pkg.generate_daily_report(SYSDATE);

    -- Test print order summary
    dhobinow_pkg.print_order_summary(1);

    -- Test calculate_bill via SELECT
    DBMS_OUTPUT.PUT_LINE('Bill for Order 1: Rs ' || dhobinow_pkg.calculate_bill(1));
END;
/

-- Test function in SELECT query
SELECT
    order_id,
    dhobinow_pkg.calculate_bill(order_id)    AS bill,
    dhobinow_pkg.get_dhobi_rating(
        NVL((SELECT dhobi_id FROM assignments a WHERE a.order_id = o.order_id), 0)
    ) AS dhobi_rating
FROM orders o;


-- ============================================================
-- SECTION F: ANONYMOUS PL/SQL BLOCKS (2+ required)
-- ============================================================

-- Anonymous Block 1: IF/ELSIF/LOOP/EXCEPTION — Revenue analysis
DECLARE
    v_total_revenue  NUMBER := 0;
    v_total_orders   NUMBER := 0;
    v_avg_order      NUMBER := 0;
    v_best_day       VARCHAR2(20);
    v_best_revenue   NUMBER := 0;

    CURSOR c_daily IS
        SELECT TO_CHAR(order_date, 'Day') AS day_name,
               SUM(total_amount) AS daily_revenue,
               COUNT(*) AS daily_orders
        FROM orders
        WHERE status != 'Cancelled'
        GROUP BY TO_CHAR(order_date, 'Day')
        ORDER BY daily_revenue DESC;
BEGIN
    DBMS_OUTPUT.PUT_LINE('========== REVENUE ANALYSIS ==========');

    -- Calculate overall stats
    SELECT NVL(SUM(total_amount), 0), COUNT(*)
    INTO v_total_revenue, v_total_orders
    FROM orders WHERE status != 'Cancelled';

    IF v_total_orders > 0 THEN
        v_avg_order := ROUND(v_total_revenue / v_total_orders, 2);
    END IF;

    DBMS_OUTPUT.PUT_LINE('Total Revenue : Rs ' || v_total_revenue);
    DBMS_OUTPUT.PUT_LINE('Total Orders  : ' || v_total_orders);
    DBMS_OUTPUT.PUT_LINE('Average Order : Rs ' || v_avg_order);

    -- Classify revenue level
    IF v_total_revenue > 10000 THEN
        DBMS_OUTPUT.PUT_LINE('Business Status: 🚀 Excellent');
    ELSIF v_total_revenue > 5000 THEN
        DBMS_OUTPUT.PUT_LINE('Business Status: 📈 Growing');
    ELSIF v_total_revenue > 1000 THEN
        DBMS_OUTPUT.PUT_LINE('Business Status: 📊 Early Stage');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Business Status: 🌱 Just Starting');
    END IF;

    -- Find busiest day using loop
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('--- Revenue by Day of Week ---');
    FOR rec IN c_daily LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(rec.day_name, 12) ||
            '| Orders: ' || RPAD(rec.daily_orders, 5) ||
            '| Revenue: Rs ' || rec.daily_revenue
        );
        IF rec.daily_revenue > v_best_revenue THEN
            v_best_revenue := rec.daily_revenue;
            v_best_day     := rec.day_name;
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Busiest Day: ' || v_best_day || ' (Rs ' || v_best_revenue || ')');
    DBMS_OUTPUT.PUT_LINE('======================================');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No order data found.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

-- Anonymous Block 2: LOOP with counter — Generate demand forecast
DECLARE
    v_day_num    NUMBER;
    v_day_name   VARCHAR2(20);
    v_count      NUMBER;
    v_bar        VARCHAR2(50);
    v_max_count  NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('======= DEMAND FORECAST (Last 30 Days) =======');

    -- Get max count for scaling
    SELECT NVL(MAX(cnt), 1) INTO v_max_count FROM (
        SELECT COUNT(*) AS cnt FROM orders
        WHERE order_date >= SYSDATE - 30
        GROUP BY TO_CHAR(order_date, 'D')
    );

    -- Loop through days 1-7
    FOR v_day_num IN 1..7 LOOP
        v_day_name := TRIM(TO_CHAR(NEXT_DAY(SYSDATE - 8, v_day_num), 'Day'));

        SELECT COUNT(*) INTO v_count
        FROM orders
        WHERE TO_CHAR(order_date, 'D') = TO_CHAR(v_day_num)
          AND order_date >= SYSDATE - 30;

        -- Build bar chart
        v_bar := RPAD('█', ROUND((v_count / v_max_count) * 20), '█');

        DBMS_OUTPUT.PUT_LINE(
            RPAD(v_day_name, 12) || ' | ' ||
            RPAD(v_bar, 20) || ' | ' ||
            v_count || ' orders'
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('==============================================');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Forecast error: ' || SQLERRM);
END;
/

-- Anonymous Block 3: Nested procedures + exception handling
DECLARE
    v_order_id  NUMBER;
    v_total     NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== Testing Full Order Pipeline ===');

    -- Place a test order
    place_order(
        p_user_id        => 1,
        p_pickup_date    => SYSDATE + 1,
        p_time_slot      => '10AM-12PM',
        p_address        => 'House 12, Block C, Faisalabad',
        p_notes          => 'Test order from anonymous block',
        p_order_id       => v_order_id
    );
    DBMS_OUTPUT.PUT_LINE('Order created: #' || v_order_id);

    -- Add items
    INSERT INTO order_items (item_id, order_id, cloth_type, quantity, service_id, price)
    VALUES (items_seq.NEXTVAL, v_order_id, 'Shirt', 3, 3, 3*80);

    INSERT INTO order_items (item_id, order_id, cloth_type, quantity, service_id, price)
    VALUES (items_seq.NEXTVAL, v_order_id, 'Jeans', 2, 1, 2*50);

    -- Calculate bill
    v_total := dhobinow_pkg.calculate_bill(v_order_id);
    DBMS_OUTPUT.PUT_LINE('Bill calculated: Rs ' || v_total);

    -- Assign a dhobi
    assign_dhobi(p_order_id => v_order_id, p_dhobi_id => 3);

    -- Update status
    update_order_status(v_order_id, 'Picked Up', 'Test Block');
    update_order_status(v_order_id, 'Washing',   'Test Block');

    -- Print summary
    dhobinow_pkg.print_order_summary(v_order_id);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Pipeline test completed successfully!');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Pipeline error: ' || SQLERRM);
END;
/
