-- ============================================================
--  DhobiNow Smart Laundry Management System
--  Database Lab Semester Project — FAST-NUCES, CFD Campus
--  CL2005 Database Systems Lab | Spring 2026
--  Script: 03_QUERIES_DML_DCL.sql
--  Run this AFTER: 01_DDL.sql and 02_DML_INSERT.sql
-- ============================================================

-- ============================================================
-- SECTION A: INDEXES (Phase 2 Requirement: 2+ indexes)
-- ============================================================

-- Index 1: Speed up order lookups by customer
CREATE INDEX idx_orders_user_id
    ON orders(user_id);

-- Index 2: Speed up status filtering on orders
CREATE INDEX idx_orders_status
    ON orders(status);

-- Index 3: Speed up item lookups by order
CREATE INDEX idx_order_items_order_id
    ON order_items(order_id);

-- Index 4: Speed up assignment lookups by dhobi
CREATE INDEX idx_assignments_dhobi_id
    ON assignments(dhobi_id);


-- ============================================================
-- SECTION B: VIEWS (Phase 2 Requirement: 2+ views)
-- ============================================================

-- View 1: Full customer order history
CREATE OR REPLACE VIEW v_customer_orders AS
SELECT
    u.user_id,
    u.name           AS customer_name,
    u.phone,
    o.order_id,
    o.order_date,
    o.pickup_date,
    o.status,
    o.total_amount,
    o.payment_method,
    o.payment_status,
    COUNT(oi.item_id) AS total_items
FROM users u
JOIN orders o ON u.user_id = o.user_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
WHERE u.role = 'customer'
GROUP BY
    u.user_id, u.name, u.phone,
    o.order_id, o.order_date, o.pickup_date,
    o.status, o.total_amount, o.payment_method, o.payment_status;

-- View 2: Dhobi workload summary
CREATE OR REPLACE VIEW v_dhobi_workload AS
SELECT
    d.user_id        AS dhobi_id,
    d.name           AS dhobi_name,
    d.phone          AS dhobi_phone,
    o.order_id,
    o.status,
    o.total_amount,
    o.pickup_date,
    a.assigned_at,
    c.name           AS customer_name,
    c.phone          AS customer_phone
FROM users d
JOIN assignments a  ON d.user_id  = a.dhobi_id
JOIN orders o       ON a.order_id = o.order_id
JOIN users c        ON o.user_id  = c.user_id
WHERE d.role = 'dhobi';

-- View 3: Daily revenue summary for admin
CREATE OR REPLACE VIEW v_daily_summary AS
SELECT
    DATE(order_date)            AS order_day,
    COUNT(*)                    AS total_orders,
    SUM(total_amount)           AS total_revenue,
    AVG(total_amount)           AS avg_order_value,
    COUNT(CASE WHEN status = 'Delivered'  THEN 1 END) AS delivered,
    COUNT(CASE WHEN status = 'Pending'    THEN 1 END) AS pending,
    COUNT(CASE WHEN status = 'Cancelled'  THEN 1 END) AS cancelled
FROM orders
GROUP BY DATE(order_date)
ORDER BY order_day DESC;

-- View 4: Service revenue analysis
CREATE OR REPLACE VIEW v_service_revenue AS
SELECT
    s.service_name,
    s.price_per_item,
    COUNT(oi.item_id)   AS times_ordered,
    SUM(oi.quantity)    AS total_items_washed,
    SUM(oi.price)       AS total_revenue
FROM services s
LEFT JOIN order_items oi ON s.service_id = oi.service_id
GROUP BY s.service_id, s.service_name, s.price_per_item
ORDER BY total_revenue DESC;


-- ============================================================
-- SECTION C: SELECT QUERIES WITH WHERE CLAUSES (5 required)
-- ============================================================

-- Query 1: Find all pending orders placed in the last 7 days
SELECT
    o.order_id,
    u.name      AS customer_name,
    u.phone     AS customer_phone,
    o.order_date,
    o.pickup_date,
    o.total_amount
FROM orders o
JOIN users u ON o.user_id = u.user_id
WHERE o.status = 'Pending'
  AND o.order_date >= NOW() - INTERVAL '7 days'
ORDER BY o.order_date DESC;

-- Query 2: Find all active dhobis with their assigned order count
SELECT
    u.user_id,
    u.name,
    u.phone,
    u.address,
    COUNT(a.assign_id) AS active_orders
FROM users u
LEFT JOIN assignments a ON u.user_id = a.dhobi_id
WHERE u.role = 'dhobi'
  AND u.is_active = true
GROUP BY u.user_id, u.name, u.phone, u.address
ORDER BY active_orders DESC;

-- Query 3: Find all orders where customer chose Dry Clean service
SELECT
    o.order_id,
    u.name      AS customer_name,
    oi.cloth_type,
    oi.quantity,
    s.service_name,
    oi.price,
    o.status
FROM orders o
JOIN users u        ON o.user_id   = u.user_id
JOIN order_items oi ON o.order_id  = oi.order_id
JOIN services s     ON oi.service_id = s.service_id
WHERE s.service_name = 'Dry Clean'
  AND o.status NOT IN ('Cancelled')
ORDER BY o.order_date DESC;

-- Query 4: Find customers who have spent more than Rs 500 total
SELECT
    u.user_id,
    u.name,
    u.phone,
    u.address,
    SUM(o.total_amount) AS lifetime_spending
FROM users u
JOIN orders o ON u.user_id = o.user_id
WHERE u.role = 'customer'
  AND o.status = 'Delivered'
GROUP BY u.user_id, u.name, u.phone, u.address
HAVING SUM(o.total_amount) > 500
ORDER BY lifetime_spending DESC;

-- Query 5: Find orders with pickup scheduled for today
SELECT
    o.order_id,
    u.name       AS customer_name,
    u.phone      AS customer_phone,
    ps.time_slot,
    ps.address   AS pickup_address,
    ps.pickup_status,
    o.total_amount
FROM orders o
JOIN users u             ON o.user_id    = u.user_id
JOIN pickup_schedule ps  ON o.order_id   = ps.order_id
WHERE ps.scheduled_date = CURRENT_DATE
  AND ps.pickup_status IN ('Confirmed', 'Pending')
ORDER BY ps.time_slot;


-- ============================================================
-- SECTION D: AGGREGATE QUERIES WITH GROUP BY (3 required)
-- ============================================================

-- Aggregate Query 1: Revenue by service type
SELECT
    s.service_name,
    COUNT(oi.item_id)       AS total_orders,
    SUM(oi.quantity)        AS total_items,
    SUM(oi.price)           AS total_revenue,
    AVG(oi.price)           AS avg_revenue_per_order,
    MAX(oi.price)           AS max_single_order,
    MIN(oi.price)           AS min_single_order
FROM services s
LEFT JOIN order_items oi ON s.service_id = oi.service_id
GROUP BY s.service_id, s.service_name
ORDER BY total_revenue DESC;

-- Aggregate Query 2: Order count and revenue by dhobi
SELECT
    d.name                          AS dhobi_name,
    d.phone,
    COUNT(DISTINCT a.order_id)      AS total_orders_handled,
    COUNT(DISTINCT CASE WHEN o.status = 'Delivered' THEN o.order_id END) AS completed_orders,
    SUM(o.total_amount)             AS total_revenue_generated,
    AVG(o.total_amount)             AS avg_order_value,
    MAX(o.total_amount)             AS highest_order
FROM users d
JOIN assignments a ON d.user_id = a.dhobi_id
JOIN orders o      ON a.order_id = o.order_id
WHERE d.role = 'dhobi'
GROUP BY d.user_id, d.name, d.phone
ORDER BY total_revenue_generated DESC;

-- Aggregate Query 3: Monthly order statistics
SELECT
    TO_CHAR(o.order_date, 'YYYY-MM') AS month,
    COUNT(*)                          AS total_orders,
    COUNT(DISTINCT o.user_id)         AS unique_customers,
    SUM(o.total_amount)               AS monthly_revenue,
    AVG(o.total_amount)               AS avg_order_value,
    COUNT(CASE WHEN o.payment_method = 'COD'    THEN 1 END) AS cod_orders,
    COUNT(CASE WHEN o.payment_method = 'Online' THEN 1 END) AS online_orders,
    COUNT(CASE WHEN o.status = 'Delivered'      THEN 1 END) AS delivered_orders
FROM orders o
GROUP BY TO_CHAR(o.order_date, 'YYYY-MM')
ORDER BY month DESC;


-- ============================================================
-- SECTION E: JOIN QUERIES (4 required)
-- ============================================================

-- Join 1: INNER JOIN — Orders with their assigned dhobi
SELECT
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount,
    c.name     AS customer_name,
    c.phone    AS customer_phone,
    d.name     AS dhobi_name,
    d.phone    AS dhobi_phone,
    a.assigned_at
FROM orders o
INNER JOIN users c      ON o.user_id   = c.user_id
INNER JOIN assignments a ON o.order_id = a.order_id
INNER JOIN users d      ON a.dhobi_id  = d.user_id
ORDER BY o.order_date DESC;

-- Join 2: LEFT OUTER JOIN — All customers including those with no orders
SELECT
    u.user_id,
    u.name        AS customer_name,
    u.phone,
    u.created_at  AS registered_on,
    COUNT(o.order_id)   AS total_orders,
    COALESCE(SUM(o.total_amount), 0) AS total_spent
FROM users u
LEFT JOIN orders o ON u.user_id = o.user_id
WHERE u.role = 'customer'
GROUP BY u.user_id, u.name, u.phone, u.created_at
ORDER BY total_orders DESC;

-- Join 3: Multi-table JOIN (4 tables) — Complete order detail report
SELECT
    o.order_id,
    c.name          AS customer,
    c.phone         AS customer_phone,
    oi.cloth_type,
    oi.quantity,
    s.service_name,
    s.price_per_item,
    oi.price        AS line_total,
    o.status,
    o.payment_method,
    d.name          AS dhobi_assigned,
    ps.time_slot    AS pickup_slot,
    ps.address      AS pickup_address
FROM orders o
JOIN users c         ON o.user_id    = c.user_id
JOIN order_items oi  ON o.order_id   = oi.order_id
JOIN services s      ON oi.service_id = s.service_id
LEFT JOIN assignments a ON o.order_id = a.order_id
LEFT JOIN users d       ON a.dhobi_id = d.user_id
LEFT JOIN pickup_schedule ps ON o.order_id = ps.order_id
ORDER BY o.order_id, oi.item_id;

-- Join 4: LEFT JOIN — All services showing usage statistics
SELECT
    s.service_id,
    s.service_name,
    s.price_per_item,
    COUNT(oi.item_id)     AS times_ordered,
    COALESCE(SUM(oi.quantity), 0) AS total_items_processed,
    COALESCE(SUM(oi.price), 0)    AS total_revenue,
    CASE
        WHEN COUNT(oi.item_id) = 0        THEN 'Not Used'
        WHEN COUNT(oi.item_id) < 5        THEN 'Low Demand'
        WHEN COUNT(oi.item_id) < 20       THEN 'Medium Demand'
        ELSE 'High Demand'
    END AS demand_level
FROM services s
LEFT JOIN order_items oi ON s.service_id = oi.service_id
GROUP BY s.service_id, s.service_name, s.price_per_item
ORDER BY total_revenue DESC;


-- ============================================================
-- SECTION F: SUBQUERIES (3 required: 1 correlated, 1 nested)
-- ============================================================

-- Subquery 1: NESTED — Find customers who have placed more orders
--             than the average number of orders per customer
SELECT
    u.name,
    u.phone,
    order_count.total_orders
FROM users u
JOIN (
    SELECT user_id, COUNT(*) AS total_orders
    FROM orders
    GROUP BY user_id
) AS order_count ON u.user_id = order_count.user_id
WHERE order_count.total_orders > (
    SELECT AVG(cnt) FROM (
        SELECT COUNT(*) AS cnt FROM orders GROUP BY user_id
    ) AS avg_sub
)
ORDER BY order_count.total_orders DESC;

-- Subquery 2: CORRELATED — Find each customer's most recent order
SELECT
    u.name     AS customer_name,
    u.phone,
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount
FROM orders o
JOIN users u ON o.user_id = u.user_id
WHERE o.order_date = (
    SELECT MAX(o2.order_date)
    FROM orders o2
    WHERE o2.user_id = o.user_id   -- correlated: references outer query
)
ORDER BY o.order_date DESC;

-- Subquery 3: Find services that have NEVER been ordered
SELECT
    service_id,
    service_name,
    price_per_item
FROM services
WHERE service_id NOT IN (
    SELECT DISTINCT service_id
    FROM order_items
    WHERE service_id IS NOT NULL
);


-- ============================================================
-- SECTION G: UPDATE STATEMENTS (2 required)
-- ============================================================

-- Update 1: Increase Wash & Iron price by 10%
UPDATE services
SET price_per_item = ROUND(price_per_item * 1.10, 0)
WHERE service_name = 'Wash & Iron';

-- Verify
SELECT service_name, price_per_item FROM services WHERE service_name = 'Wash & Iron';

-- Update 2: Mark all orders older than 30 days with status
--           still 'Pending' as 'Cancelled'
UPDATE orders
SET status = 'Cancelled'
WHERE status = 'Pending'
  AND order_date < NOW() - INTERVAL '30 days';

-- Verify
SELECT order_id, status, order_date FROM orders WHERE status = 'Cancelled';


-- ============================================================
-- SECTION H: DELETE STATEMENTS (2 required)
-- ============================================================

-- Delete 1: Remove test/demo accounts (users with no real orders)
--           Safety: only delete if they have 0 orders
DELETE FROM users
WHERE role = 'customer'
  AND is_active = false
  AND user_id NOT IN (
      SELECT DISTINCT user_id FROM orders
  );

-- Delete 2: Clean up delivery status log entries older than 90 days
--           for fully delivered orders
DELETE FROM delivery_status
WHERE order_id IN (
    SELECT order_id FROM orders WHERE status = 'Delivered'
)
AND updated_at < NOW() - INTERVAL '90 days';


-- ============================================================
-- SECTION I: DCL — GRANT and REVOKE (required)
-- ============================================================

-- Create application roles
-- (Run as superuser/admin in PostgreSQL)

-- Role for dhobi users: read orders, update status
CREATE ROLE dhobi_role;
GRANT SELECT ON orders, order_items, services, assignments, users TO dhobi_role;
GRANT UPDATE (status) ON orders TO dhobi_role;
GRANT INSERT ON delivery_status TO dhobi_role;

-- Role for customer users: read own data, insert orders
CREATE ROLE customer_role;
GRANT SELECT ON services TO customer_role;
GRANT INSERT ON orders, order_items, pickup_schedule TO customer_role;

-- Role for reporting (read-only)
CREATE ROLE report_role;
GRANT SELECT ON v_customer_orders, v_dhobi_workload, v_daily_summary, v_service_revenue TO report_role;

-- Revoke direct table access from customer (they use API only)
REVOKE DELETE ON orders FROM customer_role;
REVOKE UPDATE ON orders FROM customer_role;

-- Verify grants
SELECT grantee, table_name, privilege_type
FROM information_schema.role_table_grants
WHERE grantee IN ('dhobi_role', 'customer_role', 'report_role')
ORDER BY grantee, table_name;


-- ============================================================
-- SECTION J: ADDITIONAL USEFUL QUERIES FOR DEMO
-- ============================================================

-- Query: Full order status pipeline summary (for dashboard)
SELECT
    status,
    COUNT(*)            AS order_count,
    SUM(total_amount)   AS revenue,
    AVG(total_amount)   AS avg_value
FROM orders
GROUP BY status
ORDER BY
    CASE status
        WHEN 'Pending'          THEN 1
        WHEN 'Confirmed'        THEN 2
        WHEN 'Picked Up'        THEN 3
        WHEN 'Washing'          THEN 4
        WHEN 'Drying'           THEN 5
        WHEN 'Ironing'          THEN 6
        WHEN 'Ready'            THEN 7
        WHEN 'Out for Delivery' THEN 8
        WHEN 'Delivered'        THEN 9
        WHEN 'Cancelled'        THEN 10
    END;

-- Query: Most popular cloth types
SELECT
    cloth_type,
    COUNT(*)        AS times_ordered,
    SUM(quantity)   AS total_pieces,
    SUM(price)      AS total_revenue
FROM order_items
GROUP BY cloth_type
ORDER BY total_pieces DESC;

-- Query: Dhobi performance report (completion rate)
SELECT
    d.name                  AS dhobi_name,
    COUNT(a.order_id)       AS total_assigned,
    COUNT(CASE WHEN o.status = 'Delivered'  THEN 1 END) AS completed,
    COUNT(CASE WHEN o.status = 'Cancelled'  THEN 1 END) AS cancelled,
    ROUND(
        COUNT(CASE WHEN o.status = 'Delivered' THEN 1 END) * 100.0
        / NULLIF(COUNT(a.order_id), 0), 1
    )                       AS completion_rate_pct
FROM users d
JOIN assignments a ON d.user_id = a.dhobi_id
JOIN orders o      ON a.order_id = o.order_id
WHERE d.role = 'dhobi'
GROUP BY d.user_id, d.name
ORDER BY completion_rate_pct DESC;
